import React, { useState, useEffect, useCallback, useRef } from "react";
import {
  Trophy,
  Users,
  Flag,
  Plus,
  X,
  Play,
  RotateCcw,
  Coins,
  Clock,
  Save,
  ChevronRight,
  Minus,
  Sparkles,
  Dices,
} from "lucide-react";

const PALETTE = [
  "#C1301B", // poster red
  "#F4B93B", // poster yellow
  "#4C9A4C", // poster green
  "#4F8FD1", // poster blue
  "#8F72C4", // poster purple
  "#E8639A", // poster pink
  "#E8823D", // poster orange
  "#3F8F8F", // poster teal
  "#8FA83E", // poster olive
  "#9B6B4A", // poster brown
];

// The 36 official racers from the Magical Athlete rulebook, for quick selection.
// Ability text isn't included here — check your racer card for the exact power.
const RACER_NAMES = [
  "Alchemist", "Baba Yaga", "Banana", "Blimp", "Centaur", "Cheerleader",
  "Coach", "Copycat", "Dicemonger", "Duelist", "Egg", "Flip Flop",
  "Genius", "Gunk", "Hare", "Heckler", "Huge Baby", "Hypnotist",
  "Inchworm", "Lackey", "Leaptoad", "Legs", "Lovable Loser", "Magician",
  "Mastermind", "M.O.U.T.H.", "Party Animal", "Rocket Scientist", "Romantic",
  "Scoocher", "Sisyphus", "Skipper", "Stickler", "Suckerfish", "Third Wheel", "Twin",
];

const uid = () => Math.random().toString(36).slice(2, 10);

// ---------------------------------------------------------------------------
// Dice roller — a faithful JS port of the Backgammon Galaxy `DiceRoller`
// Elixir library (DiceRoller.CryptoRandom). MIT licensed.
//
// It uses the Web Crypto API (crypto.getRandomValues), the browser equivalent
// of Erlang's :crypto.strong_rand_bytes/1, and reproduces the same unbiased
// rejection-sampling: a random byte 0–255 is rejected when >= 252 (since
// 252 = 42*6, keeping the modulo perfectly uniform) and otherwise mapped to
// 1–6 via (byte % 6) + 1. roll(true) re-rolls until the two dice differ, the
// library's "exclude doubles" mode used for Backgammon match starts.
// ---------------------------------------------------------------------------
function rollSingleDie() {
  const buf = new Uint8Array(1);
  // Loop rather than recurse (same logic, no stack growth on the rare reject).
  for (;;) {
    crypto.getRandomValues(buf);
    const randByte = buf[0];
    if (randByte < 252) {
      return (randByte % 6) + 1;
    }
    // randByte >= 252 would bias the distribution — draw again.
  }
}

function rollDice(excludeDoubles = false) {
  if (!excludeDoubles) {
    return [rollSingleDie(), rollSingleDie()];
  }
  for (;;) {
    const a = rollSingleDie();
    const b = rollSingleDie();
    if (a !== b) return [a, b];
  }
}

// Two chrome themes. Racer colors and the "Magical Athlete" wordmark stay
// fixed across both — only backgrounds, cards, and UI accents change.
const THEMES = {
  poster: {
    label: "Poster",
    bg: "#E5402A",
    paper: "#FFFDF8",
    paper2: "#FFFCF5",
    ink: "#1A1408",
    red: "#C1301B",
    yellow: "#F4B93B",
    green: "#4C9A4C",
    purple: "#8F72C4",
    muted: "#6b6b6b",
    mutedGreen: "#3F7D3F",
    highlight: "#F5E3B3",
    onBg: "#FDE7C8",
    onBgMuted: "#FCEBC9",
  },
  calm: {
    label: "Calm",
    bg: "#1B2A22",
    paper: "#F2E8D5",
    paper2: "#F7EFDD",
    ink: "#3E5445",
    red: "#8C2F39",
    yellow: "#C9A227",
    green: "#3E7C59",
    purple: "#7B4B94",
    muted: "#6b6b6b",
    mutedGreen: "#3E7C59",
    highlight: "#E4D8B4",
    onBg: "#E8DCC0",
    onBgMuted: "#B9CDBF",
  },
};

const themeVars = (t) => ({
  "--bg": t.bg,
  "--paper": t.paper,
  "--paper2": t.paper2,
  "--ink": t.ink,
  "--red": t.red,
  "--yellow": t.yellow,
  "--green": t.green,
  "--purple": t.purple,
  "--muted": t.muted,
  "--mutedGreen": t.mutedGreen,
  "--highlight": t.highlight,
  "--onBg": t.onBg,
  "--onBgMuted": t.onBgMuted,
});

const emptyRacer = (i) => ({
  id: uid(),
  name: "",
  player: "",
  notes: "",
  color: PALETTE[i % PALETTE.length],
  position: 0,
  finished: false,
  place: null,
});

function useStorage() {
  const [ready, setReady] = useState(false);
  const [roster, setRoster] = useState(null);
  const [bettorRoster, setBettorRoster] = useState(null);
  const [historyIndex, setHistoryIndex] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const r = await window.storage.get("roster", false);
        setRoster(r ? JSON.parse(r.value) : null);
      } catch (e) {
        setRoster(null);
      }
      try {
        const b = await window.storage.get("bettor-roster", false);
        setBettorRoster(b ? JSON.parse(b.value) : null);
      } catch (e) {
        setBettorRoster(null);
      }
      try {
        const h = await window.storage.get("history-index", false);
        setHistoryIndex(h ? JSON.parse(h.value) : []);
      } catch (e) {
        setHistoryIndex([]);
      }
      setReady(true);
    })();
  }, []);

  return { ready, roster, setRoster, bettorRoster, historyIndex, setHistoryIndex };
}

export default function App() {
  const { ready, roster, bettorRoster, historyIndex, setHistoryIndex } = useStorage();

  const [mode, setMode] = useState(null); // null (chooser) | "host" | "spectator"

  const [tab, setTab] = useState("setup");
  const [themeId, setThemeId] = useState("poster");
  const theme = THEMES[themeId] || THEMES.poster;

  // --- spectator-betting session (host side) ---
  const [specEnabled, setSpecEnabled] = useState(false);
  const [sessionPin, setSessionPin] = useState(null);
  const [sessionToken, setSessionToken] = useState(null);
  const [raceId, setRaceId] = useState(() => uid());
  const knownBetKeysRef = useRef(new Set());

  const enableSpectatorBetting = async () => {
    const token = uid();
    const pin = String(Math.floor(1000 + Math.random() * 9000));
    setSessionToken(token);
    setSessionPin(pin);
    setSpecEnabled(true);
    try {
      await window.storage.set("session-pin", JSON.stringify({ pin, token, active: true }), true);
    } catch (e) {
      // best effort
    }
  };

  const disableSpectatorBetting = async () => {
    setSpecEnabled(false);
    try {
      if (sessionToken) {
        await window.storage.set(
          "session-pin",
          JSON.stringify({ pin: sessionPin, token: sessionToken, active: false }),
          true
        );
      }
    } catch (e) {
      // best effort
    }
  };

  useEffect(() => {
    (async () => {
      try {
        const saved = await window.storage.get("theme-preference", false);
        if (saved && THEMES[saved.value]) setThemeId(saved.value);
      } catch (e) {
        // best effort — default theme stands
      }
    })();
  }, []);

  const changeTheme = async (id) => {
    setThemeId(id);
    try {
      await window.storage.set("theme-preference", id, false);
    } catch (e) {
      // best effort
    }
  };
  const [status, setStatus] = useState("setup"); // setup | racing | finished
  const [trackLength, setTrackLength] = useState(30);
  const [racers, setRacers] = useState([emptyRacer(0), emptyRacer(1)]);
  const [bettors, setBettors] = useState([]);
  const [bets, setBets] = useState([]); // {id, bettorName, racerId, amount}
  const [finishOrder, setFinishOrder] = useState([]); // racer ids in finish order
  const [turnLog, setTurnLog] = useState([]);
  const [savedThisRace, setSavedThisRace] = useState(false);
  const [goldPoints, setGoldPoints] = useState("");
  const [silverPoints, setSilverPoints] = useState("");
  const [odds, setOdds] = useState({}); // racerId -> fixed decimal odds, set by the "bookie"

  // bet form
  const [betBettor, setBetBettor] = useState("");
  const [betRacer, setBetRacer] = useState("");
  const [betAmount, setBetAmount] = useState("");
  const [newBettorName, setNewBettorName] = useState("");

  // load saved roster once on ready
  useEffect(() => {
    if (ready && roster && roster.length >= 2) {
      setRacers(
        roster.map((r, i) => ({
          id: uid(),
          name: r.name,
          player: r.player || "",
          notes: r.notes || "",
          color: r.color || PALETTE[i % PALETTE.length],
          position: 0,
          finished: false,
          place: null,
        }))
      );
    }
  }, [ready]); // eslint-disable-line

  // load saved spectators once on ready
  useEffect(() => {
    if (ready && bettorRoster && bettorRoster.length > 0) {
      setBettors(bettorRoster.map((name) => ({ id: uid(), name })));
    }
  }, [ready]); // eslint-disable-line

  const persistBettors = useCallback(async (list) => {
    try {
      const payload = list.map((b) => b.name).filter((n) => n.trim());
      await window.storage.set("bettor-roster", JSON.stringify(payload), false);
    } catch (e) {
      // best effort
    }
  }, []);

  const persistRoster = useCallback(
    async (list) => {
      try {
        const payload = list
          .filter((r) => r.name.trim())
          .map((r) => ({ name: r.name, player: r.player, notes: r.notes, color: r.color }));
        await window.storage.set("roster", JSON.stringify(payload), false);
      } catch (e) {
        // best effort
      }
    },
    []
  );

  const addRacer = () => {
    const next = [...racers, emptyRacer(racers.length)];
    setRacers(next);
  };

  const updateRacer = (id, patch) => {
    const next = racers.map((r) => (r.id === id ? { ...r, ...patch } : r));
    setRacers(next);
    persistRoster(next);
  };

  const removeRacer = (id) => {
    const next = racers.filter((r) => r.id !== id);
    setRacers(next);
    persistRoster(next);
    setBets(bets.filter((b) => b.racerId !== id));
    setOdds((prev) => {
      if (!(id in prev)) return prev;
      const copy = { ...prev };
      delete copy[id];
      return copy;
    });
    if (betRacer === id) setBetRacer("");
  };

  const addBettor = () => {
    const name = newBettorName.trim();
    if (!name) return;
    const next = [...bettors, { id: uid(), name }];
    setBettors(next);
    persistBettors(next);
    setNewBettorName("");
  };

  const removeBettor = (id) => {
    const removed = bettors.find((b) => b.id === id);
    const next = bettors.filter((b) => b.id !== id);
    setBettors(next);
    persistBettors(next);
    if (removed) {
      // Drop their bets (and shared copies) so they don't linger in the pool.
      const theirBets = bets.filter((b) => b.bettorName === removed.name);
      setBets(bets.filter((b) => b.bettorName !== removed.name));
      if (specEnabled && sessionToken) {
        theirBets.forEach((b) => {
          window.storage.delete(`bet:${sessionToken}:${raceId}:${b.id}`, true).catch(() => {});
        });
      }
      if (betBettor === removed.name) setBetBettor("");
    }
  };

  const placeBet = () => {
    const amt = parseFloat(betAmount);
    if (!betBettor || !betRacer || !amt || amt <= 0 || !odds[betRacer]) return;
    const bet = { id: uid(), bettorName: betBettor, racerId: betRacer, amount: amt };
    setBets([...bets, bet]);
    setBetAmount("");
    if (specEnabled && sessionToken) {
      window.storage
        .set(`bet:${sessionToken}:${raceId}:${bet.id}`, JSON.stringify(bet), true)
        .catch(() => {});
    }
  };

  const removeBet = (id) => {
    setBets(bets.filter((b) => b.id !== id));
    if (specEnabled && sessionToken) {
      window.storage.delete(`bet:${sessionToken}:${raceId}:${id}`, true).catch(() => {});
    }
  };

  const validRacers = racers.filter((r) => r.name.trim());

  // Odds lock once money is down — or while spectators can bet from their own
  // devices, since one of their bets may be in flight between polls.
  const oddsLocked = bets.length > 0 || (specEnabled && Object.keys(odds).length > 0);

  const rollOdds = () => {
    if (oddsLocked) return;
    const map = {};
    validRacers.forEach((r) => {
      // Skewed random spread (1.5x–9x) so every racer gets a plausible but
      // unpredictable line — a new "bookie" every race.
      map[r.id] = Math.round((1.5 + Math.random() * Math.random() * 7.5) * 20) / 20;
    });
    setOdds(map);
  };


  const startRace = () => {
    if (validRacers.length < 2) return;
    setRacers(racers.map((r) => ({ ...r, position: 0, finished: false, place: null })));
    setFinishOrder([]);
    setTurnLog([]);
    setStatus("racing");
    setTab("track");
    setSavedThisRace(false);
    setGoldPoints("");
    setSilverPoints("");
  };

  const moveRacer = (id, delta) => {
    if (status !== "racing") return;
    setRacers((prev) => {
      const next = prev.map((r) => {
        if (r.id !== id || r.finished) return r;
        const pos = Math.max(0, Math.min(trackLength, r.position + delta));
        return { ...r, position: pos };
      });
      const mover = next.find((r) => r.id === id);
      if (mover && mover.position >= trackLength && !mover.finished) {
        mover.finished = true;
        setFinishOrder((fo) => {
          const already = fo.includes(id);
          const updated = already ? fo : [...fo, id];
          // A race ends the instant the 2nd racer crosses the line —
          // the rest never finish and don't score.
          if (updated.length >= 2) {
            setTimeout(() => setStatus("finished"), 0);
          }
          return updated;
        });
      }
      return next;
    });
    const racer = racers.find((r) => r.id === id);
    if (racer && !racer.finished) {
      setTurnLog((log) => [
        {
          id: uid(),
          racerName: racer.name,
          color: racer.color,
          delta,
          time: Date.now(),
        },
        ...log,
      ]);
    }
  };

  const setPositionDirect = (id, val) => {
    if (Number.isNaN(val)) return;
    const pos = Math.max(0, Math.min(trackLength, val));
    const racer = racers.find((r) => r.id === id);
    if (!racer) return;
    moveRacer(id, pos - racer.position);
  };

  const endRaceNow = () => {
    const finishedIds = finishOrder.length
      ? finishOrder
      : [...validRacers].sort((a, b) => b.position - a.position).map((r) => r.id);
    // Only 1st and 2nd place ever score, so cap it there.
    setFinishOrder(finishedIds.slice(0, 2));
    setStatus("finished");
    setTab("betting");
  };

  const resetRace = () => {
    setRacers((prev) => prev.map((r) => ({ ...r, position: 0, finished: false, place: null })));
    setFinishOrder([]);
    setTurnLog([]);
    setBets([]);
    setOdds({});
    setStatus("setup");
    setSavedThisRace(false);
    setGoldPoints("");
    setSilverPoints("");
    setRaceId(uid());
    knownBetKeysRef.current = new Set();
  };

  const newRaceKeepPeople = () => {
    setRacers((prev) => prev.map((r) => ({ ...r, position: 0, finished: false, place: null })));
    setFinishOrder([]);
    setTurnLog([]);
    setBets([]);
    setOdds({});
    setStatus("setup");
    setSavedThisRace(false);
    setGoldPoints("");
    setSilverPoints("");
    setRaceId(uid());
    knownBetKeysRef.current = new Set();
    setTab("setup");
  };

  const winnerId = finishOrder[0];
  const winner = validRacers.find((r) => r.id === winnerId);
  const runnerUpId = finishOrder[1];
  const runnerUp = validRacers.find((r) => r.id === runnerUpId);

  const totalPool = bets.reduce((s, b) => s + b.amount, 0);
  const poolByRacer = {};
  bets.forEach((b) => {
    poolByRacer[b.racerId] = (poolByRacer[b.racerId] || 0) + b.amount;
  });

  const winnerOdds = winnerId ? odds[winnerId] || 0 : 0;

  const results =
    status === "finished" && winnerId
      ? [...new Set(bets.map((b) => b.bettorName))].map((name) => {
          const theirBets = bets.filter((b) => b.bettorName === name);
          const staked = theirBets.reduce((s, b) => s + b.amount, 0);
          const won = theirBets
            .filter((b) => b.racerId === winnerId)
            .reduce((s, b) => s + b.amount * (odds[b.racerId] || 0), 0);
          return { name, staked, payout: won, net: won - staked };
        })
      : [];

  // Broadcast a read-only race snapshot for spectators, whenever their
  // betting session is on and anything relevant changes.
  useEffect(() => {
    if (!specEnabled || !sessionToken) return;
    const snapshot = {
      raceId,
      status,
      trackLength,
      racers: validRacers.map((r) => ({
        id: r.id,
        name: r.name,
        color: r.color,
        position: r.position,
        finished: r.finished,
        player: r.player,
      })),
      odds,
      finishOrder,
      winnerName: winner ? winner.name : null,
      runnerUpName: runnerUp ? runnerUp.name : null,
      updatedAt: Date.now(),
    };
    window.storage.set(`race:${sessionToken}`, JSON.stringify(snapshot), true).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [specEnabled, sessionToken, raceId, status, trackLength, racers, odds, finishOrder]);

  // Poll for bets spectators placed on their own devices and merge them in.
  useEffect(() => {
    if (!specEnabled || !sessionToken) return;
    let cancelled = false;
    const poll = async () => {
      try {
        const listRes = await window.storage.list(`bet:${sessionToken}:${raceId}:`, true);
        const keys = (listRes && listRes.keys) || [];
        const newKeys = keys.filter((k) => !knownBetKeysRef.current.has(k));
        if (newKeys.length === 0) return;
        const fetched = [];
        for (const k of newKeys) {
          try {
            const res = await window.storage.get(k, true);
            if (res) fetched.push(JSON.parse(res.value));
          } catch (e) {
            // skip a bad record
          }
        }
        newKeys.forEach((k) => knownBetKeysRef.current.add(k));
        if (cancelled || fetched.length === 0) return;
        setBets((prev) => {
          const existingIds = new Set(prev.map((b) => b.id));
          const additions = fetched.filter((b) => !existingIds.has(b.id));
          return additions.length ? [...prev, ...additions] : prev;
        });
      } catch (e) {
        // best effort — try again next tick
      }
    };
    poll();
    const interval = setInterval(poll, 4000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [specEnabled, sessionToken, raceId]);

  const saveToHistory = async () => {
    if (!winner) return;
    const placements = [
      winner && { name: winner.name, player: winner.player || "", place: 1, points: parseFloat(goldPoints) || 0 },
      runnerUp && { name: runnerUp.name, player: runnerUp.player || "", place: 2, points: parseFloat(silverPoints) || 0 },
    ].filter(Boolean);
    const record = {
      id: uid(),
      date: new Date().toISOString(),
      trackLength,
      racers: validRacers.map((r) => ({ name: r.name, player: r.player || "", color: r.color })),
      finishOrder: finishOrder
        .map((id) => validRacers.find((r) => r.id === id)?.name)
        .filter(Boolean),
      winner: winner.name,
      placements,
      totalPool,
      results: results.map((r) => ({
        name: r.name,
        staked: r.staked,
        payout: Math.round(r.payout * 100) / 100,
        net: Math.round(r.net * 100) / 100,
      })),
    };
    try {
      await window.storage.set(`race:${record.id}`, JSON.stringify(record), false);
      const idx = [record.id, ...historyIndex].slice(0, 100);
      await window.storage.set("history-index", JSON.stringify(idx), false);
      setHistoryIndex(idx);
      setSavedThisRace(true);
    } catch (e) {
      // best effort
    }
  };

  return (
    <div
      className="min-h-screen"
      style={{ ...themeVars(theme), background: "var(--bg)", fontFamily: "'Nunito', sans-serif" }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Luckiest+Guy&family=Nunito:wght@400;600;700;800&family=IBM+Plex+Mono:wght@500;600&display=swap');
        .font-display { font-family: 'Luckiest Guy', cursive; font-weight: 400; letter-spacing: 0.02em; }
        .font-mono { font-family: 'IBM Plex Mono', monospace; }
        .comic-title {
          -webkit-text-stroke: 2.5px #1A1408;
          paint-order: stroke fill;
          text-shadow: 4px 4px 0px #1A1408;
        }
        input[type=range] { accent-color: var(--yellow); }
        @keyframes trophyGlow {
          0%, 100% { filter: drop-shadow(0 0 2px var(--yellow)) brightness(1); transform: scale(1); }
          50% { filter: drop-shadow(0 0 14px var(--yellow)) brightness(1.15); transform: scale(1.08); }
        }
        .trophy-glow { animation: trophyGlow 1.8s ease-in-out infinite; }
        @keyframes winnerPop {
          0% { opacity: 0; transform: scale(0.85) translateY(6px); }
          100% { opacity: 1; transform: scale(1) translateY(0); }
        }
        .winner-pop { animation: winnerPop 0.4s cubic-bezier(0.2, 0.8, 0.2, 1) both; }
        @keyframes confettiFall {
          0% { transform: translateY(-10px) rotate(0deg); opacity: 1; }
          100% { transform: translateY(140px) rotate(360deg); opacity: 0; }
        }
        .confetti-piece { animation: confettiFall 1.6s ease-in forwards; }
        @keyframes diceTumble {
          0%   { transform: rotate(0deg) scale(1); }
          25%  { transform: rotate(-18deg) scale(1.12); }
          50%  { transform: rotate(14deg) scale(0.95); }
          75%  { transform: rotate(-8deg) scale(1.06); }
          100% { transform: rotate(0deg) scale(1); }
        }
        .dice-tumble { animation: diceTumble 0.5s ease-in-out; }
      `}</style>

      <div className="max-w-3xl mx-auto px-4 pb-24">
        <Header status={mode === "host" ? status : null} />
        <ThemeSwitcher themeId={themeId} changeTheme={changeTheme} />

        {mode === null && (
          <ModeChooser onHost={() => setMode("host")} onJoin={() => setMode("spectator")} />
        )}

        {mode === "spectator" && <SpectatorView onLeave={() => setMode(null)} />}

        {mode === "host" && (
          <>
            <TabBar tab={tab} setTab={setTab} status={status} />

            {tab === "setup" && (
              <SetupTab
                racers={racers}
                addRacer={addRacer}
                updateRacer={updateRacer}
                removeRacer={removeRacer}
                trackLength={trackLength}
                setTrackLength={setTrackLength}
                status={status}
                startRace={startRace}
                validCount={validRacers.length}
              />
            )}

            {tab === "betting" && (
              <BettingTab
                status={status}
                bettors={bettors}
                newBettorName={newBettorName}
                setNewBettorName={setNewBettorName}
                addBettor={addBettor}
                removeBettor={removeBettor}
                racers={validRacers}
                betBettor={betBettor}
                setBetBettor={setBetBettor}
                betRacer={betRacer}
                setBetRacer={setBetRacer}
                betAmount={betAmount}
                setBetAmount={setBetAmount}
                placeBet={placeBet}
                bets={bets}
                removeBet={removeBet}
                poolByRacer={poolByRacer}
                totalPool={totalPool}
                winner={winner}
                runnerUp={runnerUp}
                results={results}
                winnerOdds={winnerOdds}
                odds={odds}
                rollOdds={rollOdds}
                oddsLocked={oddsLocked}
                saveToHistory={saveToHistory}
                savedThisRace={savedThisRace}
                newRaceKeepPeople={newRaceKeepPeople}
                goldPoints={goldPoints}
                setGoldPoints={setGoldPoints}
                silverPoints={silverPoints}
                setSilverPoints={setSilverPoints}
                specEnabled={specEnabled}
                sessionPin={sessionPin}
                enableSpectatorBetting={enableSpectatorBetting}
                disableSpectatorBetting={disableSpectatorBetting}
              />
            )}

            {tab === "track" && (
              <TrackTab
                racers={racers.filter((r) => r.name.trim())}
                trackLength={trackLength}
                status={status}
                moveRacer={moveRacer}
                setPositionDirect={setPositionDirect}
                turnLog={turnLog}
                endRaceNow={endRaceNow}
                finishOrder={finishOrder}
                resetRace={resetRace}
              />
            )}

            {tab === "dice" && <DiceTab />}

            {tab === "history" && (
              <HistoryTab historyIndex={historyIndex} setHistoryIndex={setHistoryIndex} />
            )}
          </>
        )}
      </div>
    </div>
  );
}

function Header({ status }) {
  const statusLabel =
    status === "setup"
      ? "Setting up"
      : status === "racing"
      ? "Race in progress"
      : status === "finished"
      ? "Race finished"
      : "Racing game companion";
  return (
    <div className="pt-8 pb-5 text-center">
      <div className="inline-flex items-center gap-2 mb-2">
        <Sparkles size={16} color="var(--yellow)" />
        <span className="font-mono text-xs tracking-widest uppercase" style={{ color: "var(--yellow)" }}>
          Track &amp; Wager
        </span>
        <Sparkles size={16} color="var(--yellow)" />
      </div>
      <h1
        className="font-display comic-title text-5xl sm:text-6xl inline-block"
        style={{ color: "#FFFCF5", letterSpacing: "0.01em", transform: "rotate(-2deg)" }}
      >
        Magical Athlete
      </h1>
      <p className="font-mono text-xs mt-2" style={{ color: "var(--onBg)" }}>
        {statusLabel}
      </p>
    </div>
  );
}

function ThemeSwitcher({ themeId, changeTheme }) {
  return (
    <div className="flex justify-center mb-4">
      <div
        className="inline-flex rounded-full p-1 gap-1"
        style={{ background: "rgba(0,0,0,0.15)", border: "1.5px solid var(--onBgMuted)" }}
      >
        {Object.entries(THEMES).map(([id, t]) => {
          const active = themeId === id;
          return (
            <button
              key={id}
              onClick={() => changeTheme(id)}
              className="px-3.5 py-1 rounded-full text-xs font-mono font-semibold"
              style={{
                background: active ? "var(--paper)" : "transparent",
                color: active ? "var(--ink)" : "var(--onBgMuted)",
              }}
            >
              {t.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function ModeChooser({ onHost, onJoin }) {
  return (
    <div>
      <Card>
        <button onClick={onHost} className="w-full text-left flex items-center gap-3 py-2">
          <span className="text-3xl">🎪</span>
          <div>
            <p className="font-display font-bold text-lg" style={{ color: "var(--ink)" }}>
              Host a game
            </p>
            <p className="text-xs" style={{ color: "var(--muted)" }}>
              Set up racers, run the track, and open the book for betting.
            </p>
          </div>
        </button>
      </Card>
      <Card>
        <button onClick={onJoin} className="w-full text-left flex items-center gap-3 py-2">
          <span className="text-3xl">🎟️</span>
          <div>
            <p className="font-display font-bold text-lg" style={{ color: "var(--ink)" }}>
              Join with a code
            </p>
            <p className="text-xs" style={{ color: "var(--muted)" }}>
              Spectating? Enter the host's join code to place bets from your own device.
            </p>
          </div>
        </button>
      </Card>
    </div>
  );
}

function SpectatorView({ onLeave }) {
  const [joined, setJoined] = useState(false);
  const [pinInput, setPinInput] = useState("");
  const [nameInput, setNameInput] = useState("");
  const [joinError, setJoinError] = useState("");
  const [token, setToken] = useState(null);
  const [spectatorName, setSpectatorName] = useState("");
  const [snapshot, setSnapshot] = useState(null);
  const [sessionActive, setSessionActive] = useState(true);
  const [myBets, setMyBets] = useState([]);
  const lastRaceIdRef = useRef(null);

  const [betRacer, setBetRacer] = useState("");
  const [betAmount, setBetAmount] = useState("");

  const join = async () => {
    setJoinError("");
    const pin = pinInput.trim();
    const name = nameInput.trim();
    if (!/^\d{4}$/.test(pin)) {
      setJoinError("Enter the 4-digit code.");
      return;
    }
    if (!name) {
      setJoinError("Enter your name.");
      return;
    }
    try {
      const res = await window.storage.get("session-pin", true);
      if (!res) {
        setJoinError("No game is being hosted right now.");
        return;
      }
      const s = JSON.parse(res.value);
      if (!s.active || s.pin !== pin) {
        setJoinError("That code didn't match — double-check with the host.");
        return;
      }
      setToken(s.token);
      setSpectatorName(name);
      setJoined(true);
    } catch (e) {
      setJoinError("Couldn't reach the game. Try again.");
    }
  };

  useEffect(() => {
    if (!joined || !token) return;
    let cancelled = false;
    const poll = async () => {
      try {
        const res = await window.storage.get(`race:${token}`, true);
        if (!cancelled && res) {
          const snap = JSON.parse(res.value);
          if (lastRaceIdRef.current && snap.raceId !== lastRaceIdRef.current) {
            setMyBets([]);
            setBetRacer("");
            setBetAmount("");
          }
          lastRaceIdRef.current = snap.raceId;
          setSnapshot(snap);
        }
      } catch (e) {
        // try again next tick
      }
      try {
        const s = await window.storage.get("session-pin", true);
        if (!cancelled && s) {
          const parsed = JSON.parse(s.value);
          setSessionActive(!!parsed.active && parsed.token === token);
        }
      } catch (e) {
        // try again next tick
      }
    };
    poll();
    const interval = setInterval(poll, 4000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [joined, token]);

  const placeBet = async () => {
    const amt = parseFloat(betAmount);
    if (!betRacer || !amt || amt <= 0 || !snapshot || !snapshot.odds[betRacer]) return;
    const bet = { id: uid(), bettorName: spectatorName, racerId: betRacer, amount: amt };
    setMyBets((prev) => [...prev, bet]);
    setBetAmount("");
    try {
      await window.storage.set(`bet:${token}:${snapshot.raceId}:${bet.id}`, JSON.stringify(bet), true);
    } catch (e) {
      // best effort
    }
  };

  if (!joined) {
    return (
      <Card>
        <SectionTitle icon={Coins}>Join as a spectator</SectionTitle>
        <p className="text-xs mb-3" style={{ color: "var(--muted)" }}>
          Get the 4-digit code from whoever's hosting.
        </p>
        <input
          value={nameInput}
          onChange={(e) => setNameInput(e.target.value)}
          placeholder="Your name"
          className="w-full mb-2 px-3 py-2 rounded-lg border text-sm"
          style={{ borderColor: "var(--ink)", background: "var(--paper)" }}
        />
        <input
          value={pinInput}
          onChange={(e) => setPinInput(e.target.value.replace(/\D/g, "").slice(0, 4))}
          onKeyDown={(e) => e.key === "Enter" && join()}
          placeholder="4-digit code"
          inputMode="numeric"
          className="w-full mb-2 px-3 py-2 rounded-lg border text-sm font-mono text-center text-lg tracking-widest"
          style={{ borderColor: "var(--ink)", background: "var(--paper)" }}
        />
        {joinError && (
          <p className="text-xs mb-2" style={{ color: "var(--red)" }}>
            {joinError}
          </p>
        )}
        <button
          onClick={join}
          className="w-full py-3 rounded-lg text-sm font-bold mb-2"
          style={{ background: "var(--red)", color: "var(--paper2)", border: "2.5px solid var(--ink)" }}
        >
          Join
        </button>
        <button onClick={onLeave} className="w-full py-2 text-xs" style={{ color: "var(--muted)" }}>
          ← Back
        </button>
      </Card>
    );
  }

  if (!snapshot) {
    return (
      <Card>
        <p className="text-sm text-center py-6" style={{ color: "var(--muted)" }}>
          Connecting to the race…
        </p>
      </Card>
    );
  }

  const sortedRacers = [...snapshot.racers].sort((a, b) => b.position - a.position);
  const bettingOpen = snapshot.status === "setup" && sessionActive;
  const winnerId = snapshot.finishOrder && snapshot.finishOrder[0];
  const myStaked = myBets.reduce((s, b) => s + b.amount, 0);
  const myPayout =
    snapshot.status === "finished"
      ? myBets
          .filter((b) => b.racerId === winnerId)
          .reduce((s, b) => s + b.amount * (snapshot.odds[b.racerId] || 0), 0)
      : 0;

  return (
    <div>
      <Card>
        <div className="flex items-center justify-between">
          <p className="font-display font-bold text-lg" style={{ color: "var(--ink)" }}>
            Hey, {spectatorName}
          </p>
          <button onClick={onLeave} className="text-xs" style={{ color: "var(--muted)" }}>
            Leave
          </button>
        </div>
        <p className="font-mono text-xs" style={{ color: "var(--muted)" }}>
          {!sessionActive
            ? "Host closed betting"
            : snapshot.status === "setup"
            ? "Betting open"
            : snapshot.status === "racing"
            ? "Race in progress"
            : "Race finished"}
        </p>
      </Card>

      <Card>
        <SectionTitle icon={Flag}>Who's winning</SectionTitle>
        <div className="space-y-1.5">
          {sortedRacers.map((r, i) => (
            <div key={r.id} className="flex items-center gap-2 text-sm">
              <span className="font-mono text-xs w-4 text-center" style={{ color: "var(--red)" }}>
                {i + 1}
              </span>
              <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ background: r.color }} />
              <span className="flex-1 truncate">{r.name}</span>
              {r.finished && (
                <span
                  className="font-mono text-xs px-1.5 py-0.5 rounded"
                  style={{ background: "var(--yellow)", color: "var(--ink)" }}
                >
                  {winnerId === r.id ? "1st" : "2nd"}
                </span>
              )}
              <span className="font-mono text-xs" style={{ color: "var(--muted)" }}>
                {r.position}/{snapshot.trackLength}
              </span>
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <SectionTitle icon={Coins}>Odds</SectionTitle>
        <div className="space-y-1.5">
          {snapshot.racers.map((r) => (
            <div
              key={r.id}
              className="flex items-center justify-between text-sm px-2 py-1.5 rounded"
              style={{ background: "var(--paper)" }}
            >
              <span className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ background: r.color }} />
                {r.name}
              </span>
              <span className="font-mono text-sm font-semibold" style={{ color: "var(--red)" }}>
                {snapshot.odds[r.id] ? `×${snapshot.odds[r.id].toFixed(2)}` : "—"}
              </span>
            </div>
          ))}
        </div>
      </Card>

      {bettingOpen && Object.keys(snapshot.odds).length > 0 && (
        <Card>
          <SectionTitle icon={Plus}>Place a bet</SectionTitle>
          <div className="flex flex-wrap gap-1.5 mb-3">
            {snapshot.racers.map((r) => (
              <button
                key={r.id}
                onClick={() => setBetRacer(r.id)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-full text-sm font-medium border-2"
                style={{
                  background: betRacer === r.id ? "var(--green)" : "var(--paper)",
                  color: betRacer === r.id ? "var(--paper2)" : "var(--ink)",
                  borderColor: betRacer === r.id ? "var(--green)" : "var(--ink)",
                }}
              >
                <span className="w-2 h-2 rounded-full inline-block" style={{ background: r.color }} />
                {r.name}
                <span className="font-mono text-xs opacity-80">
                  ×{snapshot.odds[r.id]?.toFixed(2) ?? "—"}
                </span>
              </button>
            ))}
          </div>
          <div className="flex flex-wrap gap-1.5 mb-2">
            {[5, 10, 20, 50].map((n) => (
              <button
                key={n}
                onClick={() => setBetAmount(String(n))}
                className="px-3 py-2 rounded-lg text-sm font-mono font-semibold border-2"
                style={{
                  background: betAmount === String(n) ? "var(--yellow)" : "var(--paper)",
                  borderColor: betAmount === String(n) ? "var(--yellow)" : "var(--ink)",
                  color: "var(--ink)",
                }}
              >
                {n}
              </button>
            ))}
            <input
              type="number"
              min="0"
              step="0.5"
              value={betAmount}
              onChange={(e) => setBetAmount(e.target.value)}
              placeholder="custom"
              className="flex-1 px-2 py-2 rounded-lg border text-sm"
              style={{ borderColor: "var(--ink)", background: "var(--paper)", minWidth: 80 }}
            />
          </div>
          <button
            onClick={placeBet}
            disabled={!betRacer || !betAmount}
            className="w-full py-3 rounded-lg text-sm font-bold disabled:opacity-40"
            style={{ background: "var(--red)", color: "var(--paper2)", border: "2.5px solid var(--ink)" }}
          >
            Place bet
          </button>
        </Card>
      )}

      {myBets.length > 0 && (
        <Card>
          <SectionTitle icon={Clock}>Your bets</SectionTitle>
          <div className="space-y-1">
            {myBets.map((b) => {
              const racer = snapshot.racers.find((r) => r.id === b.racerId);
              return (
                <div key={b.id} className="flex items-center justify-between text-xs px-2 py-1">
                  <span>{racer?.name}</span>
                  <span className="font-mono">
                    {b.amount.toFixed(2)} @ ×{(snapshot.odds[b.racerId] || 0).toFixed(2)}
                  </span>
                </div>
              );
            })}
          </div>
          {snapshot.status === "finished" && (
            <div className="mt-2 pt-2" style={{ borderTop: "1.5px solid var(--ink)" }}>
              <p
                className="font-mono text-sm font-semibold"
                style={{ color: myPayout - myStaked >= 0 ? "var(--green)" : "var(--red)" }}
              >
                {myPayout - myStaked >= 0 ? "+" : ""}
                {(myPayout - myStaked).toFixed(2)} net
              </p>
            </div>
          )}
        </Card>
      )}
    </div>
  );
}

function TabBar({ tab, setTab, status }) {
  const tabs = [
    { id: "setup", label: "Racers", icon: Users },
    { id: "betting", label: "Betting", icon: Coins },
    { id: "track", label: "Track", icon: Flag },
    { id: "dice", label: "Dice", icon: Dices },
    { id: "history", label: "History", icon: Clock },
  ];
  const racing = status === "racing";
  return (
    <div
      className="flex rounded-lg overflow-hidden mb-6 border-4"
      style={{ borderColor: "var(--ink)" }}
    >
      {tabs.map((t) => {
        const active = tab === t.id;
        const lockedOut = racing && t.id !== "track" && t.id !== "dice";
        const Icon = t.icon;
        return (
          <button
            key={t.id}
            onClick={() => !lockedOut && setTab(t.id)}
            disabled={lockedOut}
            className="flex-1 flex flex-col items-center gap-1 py-2.5 text-xs font-medium transition-colors disabled:opacity-30"
            style={{
              background: active ? "var(--yellow)" : "transparent",
              color: active ? "var(--ink)" : "var(--onBgMuted)",
            }}
          >
            <Icon size={15} />
            {t.label}
          </button>
        );
      })}
    </div>
  );
}

function Card({ children, className = "" }) {
  return (
    <div
      className={`rounded-2xl border-4 p-4 mb-4 ${className}`}
      style={{
        background: "var(--paper2)",
        borderColor: "var(--ink)",
        boxShadow: "5px 5px 0px var(--ink)",
      }}
    >
      {children}
    </div>
  );
}

function SectionTitle({ children, icon: Icon }) {
  return (
    <div className="flex items-center gap-2 mb-3">
      {Icon && <Icon size={16} color="var(--red)" />}
      <h2 className="font-display font-bold text-lg" style={{ color: "var(--ink)" }}>
        {children}
      </h2>
    </div>
  );
}

const CONFETTI_COLORS = [
  "var(--yellow)",
  "var(--red)",
  "var(--green)",
  "var(--purple)",
  "#4F8FD1",
  "#E8639A",
];

function Confetti() {
  const [pieces] = useState(() =>
    Array.from({ length: 24 }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 0.4,
      color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
      size: 5 + Math.random() * 5,
    }))
  );
  return (
    <div className="relative h-0 overflow-visible pointer-events-none" aria-hidden="true">
      {pieces.map((p) => (
        <span
          key={p.id}
          className="confetti-piece absolute top-0 rounded-sm"
          style={{
            left: `${p.left}%`,
            width: p.size,
            height: p.size * 0.6,
            background: p.color,
            animationDelay: `${p.delay}s`,
          }}
        />
      ))}
    </div>
  );
}

function SetupTab({
  racers,
  addRacer,
  updateRacer,
  removeRacer,
  trackLength,
  setTrackLength,
  status,
  startRace,
  validCount,
}) {
  const locked = status !== "setup";
  const [expanded, setExpanded] = useState({});
  const toggleExpanded = (id) => setExpanded((e) => ({ ...e, [id]: !e[id] }));
  return (
    <div>
      <Card>
        <SectionTitle icon={Flag}>Track length</SectionTitle>
        <div className="flex items-center gap-3">
          <input
            type="range"
            min="10"
            max="60"
            value={trackLength}
            disabled={locked}
            onChange={(e) => setTrackLength(parseInt(e.target.value))}
            className="flex-1"
          />
          <span className="font-mono font-semibold text-sm" style={{ color: "var(--red)" }}>
            {trackLength} spaces
          </span>
        </div>
      </Card>

      <Card>
        <SectionTitle icon={Users}>Racers</SectionTitle>
        <p className="text-xs mb-2" style={{ color: "var(--muted)" }}>
          Type a name to autocomplete from the official 36 — or enter your own for a custom or
          expansion racer.
        </p>
        <datalist id="racer-names">
          {RACER_NAMES.map((n) => (
            <option key={n} value={n} />
          ))}
        </datalist>
        <div className="space-y-3">
          {racers.map((r, i) => (
            <div key={r.id} className="rounded-lg p-2" style={{ background: "var(--paper)" }}>
              <div className="flex items-center gap-2 mb-1.5">
                <div className="flex gap-1 shrink-0">
                  {PALETTE.slice(0, 5).map((c) => (
                    <button
                      key={c}
                      onClick={() => !locked && updateRacer(r.id, { color: c })}
                      className="w-4 h-4 rounded-full border"
                      aria-label={`Set ${r.name || "racer"}'s color`}
                      aria-pressed={r.color === c}
                      style={{
                        background: c,
                        borderColor: r.color === c ? "var(--ink)" : "transparent",
                        borderWidth: 2,
                      }}
                    />
                  ))}
                </div>
                <input
                  value={r.name}
                  disabled={locked}
                  list="racer-names"
                  onChange={(e) => updateRacer(r.id, { name: e.target.value })}
                  placeholder={`Racer ${i + 1} name`}
                  className="flex-1 min-w-0 px-2 py-1.5 rounded border text-sm font-medium"
                  style={{ borderColor: "var(--ink)", background: "var(--paper)" }}
                />
                {!locked && racers.length > 2 && (
                  <button onClick={() => removeRacer(r.id)} className="shrink-0 p-1" aria-label={`Remove ${r.name || "racer"}`}>
                    <X size={16} color="var(--red)" />
                  </button>
                )}
              </div>
              <div className="flex items-center gap-1.5">
                <input
                  value={r.player}
                  disabled={locked}
                  onChange={(e) => updateRacer(r.id, { player: e.target.value })}
                  placeholder="racing player (optional)"
                  className="flex-1 min-w-0 px-2 py-1 rounded border text-xs"
                  style={{ borderColor: "var(--ink)", background: "var(--paper)" }}
                />
                <button
                  onClick={() => toggleExpanded(r.id)}
                  className="shrink-0 text-xs font-mono px-2 py-1"
                  style={{ color: "var(--muted)" }}
                >
                  {expanded[r.id] ? "▲ less" : "▼ more"}
                </button>
              </div>
              {expanded[r.id] && (
                <input
                  value={r.notes}
                  disabled={locked}
                  onChange={(e) => updateRacer(r.id, { notes: e.target.value })}
                  placeholder="ability notes (optional)"
                  className="w-full mt-1.5 px-2 py-1 rounded border text-xs"
                  style={{ borderColor: "var(--ink)", background: "var(--paper)" }}
                />
              )}
            </div>
          ))}
        </div>
        {!locked && (
          <button
            onClick={addRacer}
            className="mt-3 flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-lg"
            style={{ background: "var(--green)", color: "var(--paper2)", border: "2.5px solid var(--ink)" }}
          >
            <Plus size={14} /> Add racer
          </button>
        )}
      </Card>

      {status === "setup" && (
        <div className="sticky bottom-3 z-20 pt-1">
          <button
            onClick={startRace}
            disabled={validCount < 2}
            className="w-full flex items-center justify-center gap-2 py-3.5 rounded-lg font-display font-bold text-base disabled:opacity-40 shadow-lg"
            style={{ background: "var(--red)", color: "var(--paper2)", border: "3px solid var(--ink)", boxShadow: "5px 5px 0px var(--ink)" }}
          >
            <Play size={18} /> Lock roster &amp; start race
          </button>
        </div>
      )}
      {validCount < 2 && status === "setup" && (
        <p className="text-center text-xs mt-2" style={{ color: "var(--onBg)" }}>
          Add at least two named racers to start.
        </p>
      )}
    </div>
  );
}

function BettingTab(props) {
  const {
    status,
    bettors,
    newBettorName,
    setNewBettorName,
    addBettor,
    removeBettor,
    racers,
    betBettor,
    setBetBettor,
    betRacer,
    setBetRacer,
    betAmount,
    setBetAmount,
    placeBet,
    bets,
    removeBet,
    poolByRacer,
    totalPool,
    winner,
    runnerUp,
    results,
    winnerOdds,
    odds,
    rollOdds,
    oddsLocked,
    saveToHistory,
    savedThisRace,
    newRaceKeepPeople,
    goldPoints,
    setGoldPoints,
    silverPoints,
    setSilverPoints,
    specEnabled,
    sessionPin,
    enableSpectatorBetting,
    disableSpectatorBetting,
  } = props;

  const bettingOpen = status === "setup";

  if (status === "finished") {
    return (
      <div>
        <Confetti />
        <Card>
          <div className="text-center winner-pop">
            <Trophy size={36} color="var(--yellow)" className="mx-auto mb-2 trophy-glow" />
            <p className="font-mono text-xs uppercase tracking-widest" style={{ color: "var(--red)" }}>
              Winner
            </p>
            <p className="font-display font-bold text-3xl" style={{ color: "var(--ink)" }}>
              {winner ? winner.name : "—"}
            </p>
            {winner?.player && (
              <p className="text-xs" style={{ color: "var(--muted)" }}>
                racing for {winner.player}
              </p>
            )}
            {runnerUp && (
              <p className="text-xs mt-1" style={{ color: "var(--muted)" }}>
                2nd: {runnerUp.name}
                {runnerUp.player ? ` (${runnerUp.player})` : ""}
              </p>
            )}
            <p className="font-mono text-xs mt-1" style={{ color: "var(--mutedGreen)" }}>
              Winning odds were ×{winnerOdds ? winnerOdds.toFixed(2) : "0.00"} · {totalPool.toFixed(2)} total staked
            </p>
          </div>
        </Card>

        <Card>
          <SectionTitle icon={Trophy}>Chips awarded</SectionTitle>
          <p className="text-xs mb-2" style={{ color: "var(--muted)" }}>
            Enter the point value on the gold and silver chips you actually drew, so standings can
            track them across races.
          </p>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs font-mono uppercase" style={{ color: "var(--red)" }}>
                Gold (1st)
              </label>
              <input
                type="number"
                min="0"
                value={goldPoints}
                onChange={(e) => setGoldPoints(e.target.value)}
                placeholder="points"
                className="w-full mt-0.5 px-2 py-1.5 rounded border text-sm"
                style={{ borderColor: "var(--ink)", background: "var(--paper)" }}
              />
            </div>
            <div>
              <label className="text-xs font-mono uppercase" style={{ color: "var(--muted)" }}>
                Silver (2nd)
              </label>
              <input
                type="number"
                min="0"
                value={silverPoints}
                onChange={(e) => setSilverPoints(e.target.value)}
                placeholder="points"
                className="w-full mt-0.5 px-2 py-1.5 rounded border text-sm"
                style={{ borderColor: "var(--ink)", background: "var(--paper)" }}
              />
            </div>
          </div>
        </Card>

        <Card>
          <SectionTitle icon={Coins}>Payouts</SectionTitle>
          {results.length === 0 && (
            <p className="text-sm" style={{ color: "var(--muted)" }}>
              No bets were placed on this race.
            </p>
          )}
          <div className="space-y-1.5">
            {results.map((r) => (
              <div
                key={r.name}
                className="flex items-center justify-between text-sm px-2 py-1.5 rounded"
                style={{ background: "var(--paper)" }}
              >
                <span className="font-medium">{r.name}</span>
                <span className="font-mono text-xs" style={{ color: "var(--muted)" }}>
                  staked {r.staked.toFixed(2)}
                </span>
                <span
                  className="font-mono text-sm font-semibold"
                  style={{ color: r.net >= 0 ? "var(--green)" : "var(--red)" }}
                >
                  {r.net >= 0 ? "+" : ""}
                  {r.net.toFixed(2)}
                </span>
              </div>
            ))}
          </div>
        </Card>

        <div className="flex gap-2">
          <button
            onClick={saveToHistory}
            disabled={savedThisRace}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg font-medium text-sm disabled:opacity-50"
            style={{ background: "var(--green)", color: "var(--paper2)", border: "2.5px solid var(--ink)" }}
          >
            <Save size={15} /> {savedThisRace ? "Saved to history" : "Save result"}
          </button>
          <button
            onClick={newRaceKeepPeople}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg font-medium text-sm"
            style={{ background: "var(--yellow)", color: "var(--ink)", border: "2.5px solid var(--ink)" }}
          >
            <RotateCcw size={15} /> New race
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      {bettingOpen && (
        <Card>
          <SectionTitle icon={Coins}>Bet from your own phone</SectionTitle>
          {!specEnabled ? (
            <>
              <p className="text-xs mb-2" style={{ color: "var(--muted)" }}>
                Turn this on and spectators can join with a 4-digit code and place bets from
                their own device instead of passing yours around.
              </p>
              <button
                onClick={enableSpectatorBetting}
                className="w-full py-2.5 rounded-lg text-sm font-bold"
                style={{ background: "var(--purple)", color: "var(--paper2)", border: "2.5px solid var(--ink)" }}
              >
                📡 Enable spectator betting
              </button>
            </>
          ) : (
            <>
              <p className="text-xs mb-1" style={{ color: "var(--muted)" }}>
                Have spectators open this same page, tap "Join with a code," and enter:
              </p>
              <p
                className="font-mono font-bold text-4xl text-center py-2"
                style={{ color: "var(--red)", letterSpacing: "0.3em" }}
              >
                {sessionPin}
              </p>
              <button
                onClick={disableSpectatorBetting}
                className="w-full py-2 rounded-lg text-xs font-medium"
                style={{ background: "var(--paper)", color: "var(--muted)", border: "1.5px solid var(--ink)" }}
              >
                Stop hosting spectator betting
              </button>
            </>
          )}
        </Card>
      )}
      <Card>
        <SectionTitle icon={Users}>Spectators</SectionTitle>
        <p className="text-xs mb-2" style={{ color: "var(--muted)" }}>
          Anyone can bet on a racer, whether or not they're playing.
        </p>
        <div className="flex flex-wrap gap-1.5 mb-2">
          {bettors.map((b) => (
            <span
              key={b.id}
              className="flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium"
              style={{ background: "var(--highlight)" }}
            >
              {b.name}
              <button onClick={() => removeBettor(b.id)} aria-label={`Remove ${b.name}`}>
                <X size={11} />
              </button>
            </span>
          ))}
        </div>
        {bettingOpen && (
          <div className="flex gap-2">
            <input
              value={newBettorName}
              onChange={(e) => setNewBettorName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addBettor()}
              placeholder="Spectator name"
              className="flex-1 px-2 py-1.5 rounded border text-sm"
              style={{ borderColor: "var(--ink)", background: "var(--paper)" }}
            />
            <button
              onClick={addBettor}
              className="px-3 py-1.5 rounded-lg text-sm font-medium"
              style={{ background: "var(--green)", color: "var(--paper2)", border: "2.5px solid var(--ink)" }}
            >
              <Plus size={14} />
            </button>
          </div>
        )}
      </Card>

      <Card>
        <SectionTitle icon={Coins}>Odds board</SectionTitle>
        {racers.length === 0 ? (
          <p className="text-sm" style={{ color: "var(--muted)" }}>
            Add racers first.
          </p>
        ) : (
          <React.Fragment>
            <div className="space-y-1.5">
              {racers.map((r) => {
                const pool = poolByRacer[r.id] || 0;
                const racerOdds = odds[r.id];
                return (
                  <div
                    key={r.id}
                    className="flex items-center justify-between text-sm px-2 py-1.5 rounded"
                    style={{ background: "var(--paper)" }}
                  >
                    <span className="flex items-center gap-2">
                      <span
                        className="w-2.5 h-2.5 rounded-full inline-block"
                        style={{ background: r.color }}
                      />
                      {r.name}
                    </span>
                    <span className="font-mono text-xs" style={{ color: "var(--muted)" }}>
                      {pool > 0 ? `${pool.toFixed(2)} staked` : ""}
                    </span>
                    <span className="font-mono text-sm font-semibold" style={{ color: "var(--red)" }}>
                      {racerOdds ? `×${racerOdds.toFixed(2)}` : "—"}
                    </span>
                  </div>
                );
              })}
            </div>
            {bettingOpen && (
              <button
                onClick={rollOdds}
                disabled={oddsLocked}
                className="mt-3 w-full flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium disabled:opacity-50"
                style={{ background: "var(--purple)", color: "var(--paper2)", border: "2.5px solid var(--ink)" }}
              >
                🎲 {Object.keys(odds).length ? "Reroll odds" : "Post odds"}
              </button>
            )}
            {oddsLocked && bettingOpen && (
              <p className="text-center text-xs font-mono mt-1.5" style={{ color: "var(--red)" }}>
                {bets.length > 0
                  ? "Odds are locked in — bets are already down."
                  : "Odds are locked while spectator betting is live."}
              </p>
            )}
          </React.Fragment>
        )}
        <p className="font-mono text-xs mt-2" style={{ color: "var(--muted)" }}>
          Odds are randomized fresh each race and lock the moment the first bet lands. Payout =
          stake × odds on the winner.
        </p>
      </Card>

      {bettingOpen && Object.keys(odds).length === 0 && racers.length > 0 && (
        <Card>
          <p className="text-sm text-center py-2" style={{ color: "var(--muted)" }}>
            Post odds above before spectators can bet.
          </p>
        </Card>
      )}

      {bettingOpen && Object.keys(odds).length > 0 && (
        <Card>
          <SectionTitle icon={Plus}>Place a bet</SectionTitle>

          <p className="text-xs font-mono uppercase mb-1.5" style={{ color: "var(--muted)" }}>
            Who's betting?
          </p>
          <div className="flex flex-wrap gap-1.5 mb-3">
            {bettors.map((b) => (
              <button
                key={b.id}
                onClick={() => setBetBettor(b.name)}
                className="px-3 py-2 rounded-full text-sm font-medium border-2"
                style={{
                  background: betBettor === b.name ? "var(--red)" : "var(--paper)",
                  color: betBettor === b.name ? "var(--paper2)" : "var(--ink)",
                  borderColor: betBettor === b.name ? "var(--red)" : "var(--ink)",
                }}
              >
                {b.name}
              </button>
            ))}
          </div>

          <p className="text-xs font-mono uppercase mb-1.5" style={{ color: "var(--muted)" }}>
            On which racer?
          </p>
          <div className="flex flex-wrap gap-1.5 mb-3">
            {racers.map((r) => (
              <button
                key={r.id}
                onClick={() => setBetRacer(r.id)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-full text-sm font-medium border-2"
                style={{
                  background: betRacer === r.id ? "var(--green)" : "var(--paper)",
                  color: betRacer === r.id ? "var(--paper2)" : "var(--ink)",
                  borderColor: betRacer === r.id ? "var(--green)" : "var(--ink)",
                }}
              >
                <span className="w-2 h-2 rounded-full inline-block" style={{ background: r.color }} />
                {r.name}
                <span className="font-mono text-xs opacity-80">×{odds[r.id]?.toFixed(2) ?? "—"}</span>
              </button>
            ))}
          </div>

          <p className="text-xs font-mono uppercase mb-1.5" style={{ color: "var(--muted)" }}>
            Amount
          </p>
          <div className="flex flex-wrap gap-1.5 mb-2">
            {[5, 10, 20, 50].map((n) => (
              <button
                key={n}
                onClick={() => setBetAmount(String(n))}
                className="px-3 py-2 rounded-lg text-sm font-mono font-semibold border-2"
                style={{
                  background: betAmount === String(n) ? "var(--yellow)" : "var(--paper)",
                  borderColor: betAmount === String(n) ? "var(--yellow)" : "var(--ink)",
                  color: "var(--ink)",
                }}
              >
                {n}
              </button>
            ))}
            <input
              type="number"
              min="0"
              step="0.5"
              value={betAmount}
              onChange={(e) => setBetAmount(e.target.value)}
              placeholder="custom"
              className="flex-1 px-2 py-2 rounded-lg border text-sm"
              style={{ borderColor: "var(--ink)", background: "var(--paper)", minWidth: 80 }}
            />
          </div>

          <button
            onClick={placeBet}
            disabled={!betBettor || !betRacer || !betAmount}
            className="w-full py-3 rounded-lg text-sm font-bold disabled:opacity-40"
            style={{ background: "var(--red)", color: "var(--paper2)", border: "2.5px solid var(--ink)" }}
          >
            Place bet
          </button>
        </Card>
      )}

      {bets.length > 0 && (
        <Card>
          <SectionTitle icon={Clock}>Bet slips</SectionTitle>
          <div className="space-y-1">
            {bets.map((b) => {
              const racer = racers.find((x) => x.id === b.racerId);
              return (
                <div key={b.id} className="flex items-center justify-between text-xs px-2 py-1">
                  <span>
                    {b.bettorName} → {racer?.name}
                  </span>
                  <span className="flex items-center gap-2 font-mono">
                    {b.amount.toFixed(2)}
                    {bettingOpen && (
                      <button onClick={() => removeBet(b.id)} aria-label="Cancel this bet">
                        <X size={12} />
                      </button>
                    )}
                  </span>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {!bettingOpen && status === "racing" && (
        <p className="text-center text-xs" style={{ color: "var(--yellow)" }}>
          Betting is locked — the race is on.
        </p>
      )}
    </div>
  );
}

function TrackTab({
  racers,
  trackLength,
  status,
  moveRacer,
  setPositionDirect,
  turnLog,
  endRaceNow,
  finishOrder,
  resetRace,
}) {
  const [expandedId, setExpandedId] = useState(null);

  if (status === "setup") {
    return (
      <Card>
        <p className="text-sm text-center py-6" style={{ color: "var(--muted)" }}>
          Start the race from the Racers tab to begin tracking positions.
        </p>
      </Card>
    );
  }

  const sorted = [...racers].sort((a, b) => b.position - a.position);

  return (
    <div>
      <Card className="!p-2">
        {sorted.map((r, i) => {
          const place = finishOrder.indexOf(r.id);
          const isOpen = expandedId === r.id;
          const canMove = status === "racing" && !r.finished;
          return (
            <div
              key={r.id}
              className="rounded-lg mb-1.5 last:mb-0 overflow-hidden"
              style={{ background: "var(--paper)" }}
            >
              <button
                onClick={() => canMove && setExpandedId(isOpen ? null : r.id)}
                className="w-full flex items-center gap-2 px-2.5 py-2.5 text-left"
                style={{ minHeight: 48 }}
              >
                <span
                  className="font-mono text-xs font-bold w-4 text-center shrink-0"
                  style={{ color: "var(--red)" }}
                >
                  {i + 1}
                </span>
                <span
                  className="w-2.5 h-2.5 rounded-full inline-block shrink-0"
                  style={{ background: r.color }}
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="font-display font-bold text-sm truncate">{r.name}</span>
                    {r.player && (
                      <span className="text-xs truncate" style={{ color: "var(--muted)" }}>
                        {r.player}
                      </span>
                    )}
                    {r.finished && (
                      <span
                        className="font-mono text-xs px-1.5 py-0.5 rounded shrink-0"
                        style={{ background: "var(--yellow)", color: "var(--ink)" }}
                      >
                        {place === 0 ? "1st" : "2nd"}
                      </span>
                    )}
                  </div>
                  <div
                    className="relative h-1.5 rounded-full mt-1 overflow-hidden"
                    style={{ background: "var(--highlight)" }}
                  >
                    <div
                      className="absolute top-0 left-0 h-full rounded-full transition-all"
                      style={{ width: `${(r.position / trackLength) * 100}%`, background: r.color }}
                    />
                  </div>
                </div>
                <span
                  className="font-mono text-xs font-semibold shrink-0"
                  style={{ color: "var(--red)" }}
                >
                  {r.position}/{trackLength}
                </span>
              </button>

              {isOpen && canMove && (
                <div className="flex flex-wrap items-center gap-1.5 px-2.5 pb-2.5">
                  <button
                    onClick={() => moveRacer(r.id, -1)}
                    className="rounded flex items-center justify-center"
                    style={{ background: "var(--highlight)", minWidth: 44, minHeight: 44 }}
                    aria-label={`Move ${r.name} back 1 space`}
                  >
                    <Minus size={16} />
                  </button>
                  {[1, 2, 3, 5].map((n) => (
                    <button
                      key={n}
                      onClick={() => moveRacer(r.id, n)}
                      className="rounded text-sm font-mono font-bold flex items-center justify-center"
                      style={{ background: "var(--green)", color: "var(--paper2)", minWidth: 44, minHeight: 44 }}
                    >
                      +{n}
                    </button>
                  ))}
                  <input
                    type="number"
                    placeholder="jump to…"
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && e.target.value !== "") {
                        setPositionDirect(r.id, parseInt(e.target.value));
                        e.target.value = "";
                      }
                    }}
                    className="flex-1 px-2 rounded border text-sm"
                    style={{ borderColor: "var(--ink)", background: "var(--paper)", minHeight: 44, minWidth: 80 }}
                  />
                </div>
              )}
            </div>
          );
        })}
      </Card>

      <div className="sticky bottom-3 z-20">
        {status === "racing" && (
          <button
            onClick={endRaceNow}
            className="w-full flex items-center justify-center gap-2 py-3.5 rounded-lg font-medium text-sm mb-4 shadow-lg"
            style={{ background: "var(--red)", color: "var(--paper2)", border: "3px solid var(--ink)", boxShadow: "5px 5px 0px var(--ink)" }}
          >
            <ChevronRight size={16} /> End race &amp; settle bets
          </button>
        )}
        {status === "finished" && (
          <button
            onClick={resetRace}
            className="w-full flex items-center justify-center gap-2 py-3.5 rounded-lg font-medium text-sm mb-4 shadow-lg"
            style={{ background: "var(--yellow)", color: "var(--ink)", border: "3px solid var(--ink)", boxShadow: "5px 5px 0px var(--ink)" }}
          >
            <RotateCcw size={16} /> Edit roster for next race
          </button>
        )}
      </div>

      {turnLog.length > 0 && (
        <Card>
          <SectionTitle icon={Clock}>Move log</SectionTitle>
          <div className="space-y-1 max-h-52 overflow-y-auto">
            {turnLog.map((t) => (
              <div key={t.id} className="flex items-center gap-2 text-xs">
                <span className="w-2 h-2 rounded-full inline-block" style={{ background: t.color }} />
                <span className="font-medium">{t.racerName}</span>
                <span className="font-mono" style={{ color: t.delta >= 0 ? "var(--green)" : "var(--red)" }}>
                  {t.delta >= 0 ? `+${t.delta}` : t.delta}
                </span>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

// Pip layouts for each die face (3x3 grid, 1 = pip present).
const PIP_LAYOUTS = {
  1: [0, 0, 0, 0, 1, 0, 0, 0, 0],
  2: [1, 0, 0, 0, 0, 0, 0, 0, 1],
  3: [1, 0, 0, 0, 1, 0, 0, 0, 1],
  4: [1, 0, 1, 0, 0, 0, 1, 0, 1],
  5: [1, 0, 1, 0, 1, 0, 1, 0, 1],
  6: [1, 0, 1, 1, 0, 1, 1, 0, 1],
};

function DieFace({ value, rolling, color }) {
  return (
    <div
      className={`rounded-2xl grid grid-cols-3 grid-rows-3 gap-0.5 p-3 ${rolling ? "dice-tumble" : ""}`}
      style={{
        width: 96,
        height: 96,
        background: "var(--paper2)",
        border: "3px solid var(--ink)",
        boxShadow: "4px 4px 0px var(--ink)",
      }}
    >
      {(PIP_LAYOUTS[value] || PIP_LAYOUTS[1]).map((on, i) => (
        <div key={i} className="flex items-center justify-center">
          {on ? (
            <span
              className="rounded-full"
              style={{ width: 16, height: 16, background: color || "var(--ink)" }}
            />
          ) : null}
        </div>
      ))}
    </div>
  );
}

function DiceTab() {
  const [dice, setDice] = useState([1, 1]);
  const [rolled, setRolled] = useState(false);
  const [rolling, setRolling] = useState(false);
  const [excludeDoubles, setExcludeDoubles] = useState(false);
  const [history, setHistory] = useState([]);
  const timeoutRef = useRef(null);

  useEffect(() => () => clearTimeout(timeoutRef.current), []);

  const doRoll = () => {
    setRolling(true);
    setRolled(true);
    // Settle on the real (crypto-random) result after a short tumble.
    clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      const result = rollDice(excludeDoubles);
      setDice(result);
      setRolling(false);
      setHistory((h) => [{ id: uid(), dice: result }, ...h].slice(0, 12));
    }, 450);
  };

  const isDouble = rolled && !rolling && dice[0] === dice[1];
  const total = dice[0] + dice[1];

  return (
    <div>
      <Card>
        <div className="flex items-center justify-center gap-4 py-4">
          <DieFace value={dice[0]} rolling={rolling} color="var(--red)" />
          <DieFace value={dice[1]} rolling={rolling} color="var(--purple)" />
        </div>
        <div className="text-center" style={{ minHeight: 24 }}>
          {rolled && !rolling && (
            <p className="font-mono text-sm" style={{ color: "var(--muted)" }}>
              Total {total}
              {isDouble && (
                <span className="font-bold" style={{ color: "var(--red)" }}>
                  {"  ·  DOUBLES!"}
                </span>
              )}
            </p>
          )}
        </div>
        <button
          onClick={doRoll}
          disabled={rolling}
          className="w-full flex items-center justify-center gap-2 py-3.5 rounded-lg font-display font-bold text-base mt-2 disabled:opacity-60"
          style={{ background: "var(--red)", color: "var(--paper2)", border: "3px solid var(--ink)", boxShadow: "5px 5px 0px var(--ink)" }}
        >
          <Dices size={20} /> {rolled ? "Roll again" : "Roll dice"}
        </button>
      </Card>

      <Card>
        <label className="flex items-center gap-3 cursor-pointer">
          <button
            onClick={() => setExcludeDoubles((v) => !v)}
            className="shrink-0 rounded-full transition-colors"
            role="switch"
            aria-checked={excludeDoubles}
            aria-label="Exclude doubles"
            style={{
              width: 44,
              height: 26,
              background: excludeDoubles ? "var(--green)" : "var(--highlight)",
              border: "2px solid var(--ink)",
              position: "relative",
            }}
          >
            <span
              className="rounded-full block"
              style={{
                width: 18,
                height: 18,
                background: "var(--paper2)",
                border: "1.5px solid var(--ink)",
                position: "absolute",
                top: 2,
                left: excludeDoubles ? 22 : 2,
                transition: "left 0.15s",
              }}
            />
          </button>
          <div>
            <p className="text-sm font-medium" style={{ color: "var(--ink)" }}>
              Exclude doubles
            </p>
            <p className="text-xs" style={{ color: "var(--muted)" }}>
              Re-rolls until the two dice differ — the "match start" rule for opening moves.
            </p>
          </div>
        </label>
      </Card>

      {history.length > 0 && (
        <Card>
          <SectionTitle icon={Clock}>Recent rolls</SectionTitle>
          <div className="flex flex-wrap gap-1.5">
            {history.map((h) => (
              <span
                key={h.id}
                className="font-mono text-sm px-2 py-1 rounded"
                style={{ background: "var(--paper)", border: "1.5px solid var(--ink)" }}
              >
                {h.dice[0]}-{h.dice[1]}
                {h.dice[0] === h.dice[1] ? " ✦" : ""}
              </span>
            ))}
          </div>
          <p className="font-mono text-xs mt-2" style={{ color: "var(--muted)" }}>
            Cryptographically fair rolls (unbiased 1–6).
          </p>
        </Card>
      )}
    </div>
  );
}

function HistoryTab({ historyIndex }) {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      const loaded = [];
      for (const id of historyIndex) {
        try {
          const res = await window.storage.get(`race:${id}`, false);
          if (res) loaded.push(JSON.parse(res.value));
        } catch (e) {
          // skip
        }
      }
      setRecords(loaded);
      setLoading(false);
    })();
  }, [historyIndex]);

  if (loading) {
    return (
      <Card>
        <p className="text-sm text-center py-6" style={{ color: "var(--muted)" }}>
          Loading history…
        </p>
      </Card>
    );
  }

  if (records.length === 0) {
    return (
      <Card>
        <p className="text-sm text-center py-6" style={{ color: "var(--muted)" }}>
          No saved races yet. Finish a race and save it to build a history here.
        </p>
      </Card>
    );
  }

  const standings = {};
  records.forEach((r) => {
    (r.placements || []).forEach((p) => {
      if (!p.player) return;
      standings[p.player] = (standings[p.player] || 0) + (p.points || 0);
    });
  });
  const standingsList = Object.entries(standings).sort((a, b) => b[1] - a[1]);

  return (
    <div>
      {standingsList.length > 0 && (
        <Card>
          <SectionTitle icon={Trophy}>Standings</SectionTitle>
          <p className="text-xs mb-2" style={{ color: "var(--muted)" }}>
            Total gold/silver chip points across every saved race — your running tournament score.
          </p>
          <div className="space-y-1">
            {standingsList.map(([player, pts], i) => (
              <div
                key={player}
                className="flex items-center justify-between text-sm px-2 py-1.5 rounded"
                style={{ background: i === 0 ? "var(--highlight)" : "var(--paper)" }}
              >
                <span className="font-medium">
                  {i === 0 ? "🥇 " : i === 1 ? "🥈 " : i === 2 ? "🥉 " : ""}
                  {player}
                </span>
                <span className="font-mono font-semibold" style={{ color: "var(--red)" }}>
                  {pts}
                </span>
              </div>
            ))}
          </div>
        </Card>
      )}
      {records.map((r) => (
        <Card key={r.id}>
          <div className="flex items-center justify-between mb-1">
            <span className="font-display font-bold text-base">{r.winner}</span>
            <span className="font-mono text-xs" style={{ color: "var(--muted)" }}>
              {new Date(r.date).toLocaleDateString()}
            </span>
          </div>
          <p className="text-xs mb-2" style={{ color: "var(--muted)" }}>
            {r.finishOrder.join(" → ")}
          </p>
          {(r.placements || []).some((p) => p.player) && (
            <p className="text-xs mb-2 font-mono" style={{ color: "var(--mutedGreen)" }}>
              {r.placements
                .filter((p) => p.player)
                .map((p) => `${p.player} +${p.points}`)
                .join(" · ")}
            </p>
          )}
          {r.results.length > 0 && (
            <div className="space-y-0.5">
              {r.results.map((res, i) => (
                <div key={i} className="flex justify-between text-xs font-mono">
                  <span>{res.name}</span>
                  <span style={{ color: res.net >= 0 ? "var(--green)" : "var(--red)" }}>
                    {res.net >= 0 ? "+" : ""}
                    {res.net.toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </Card>
      ))}
    </div>
  );
}
